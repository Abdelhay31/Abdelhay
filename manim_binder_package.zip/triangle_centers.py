
from manim import *
import numpy as np

class TriangleCenters(Scene):
    def construct(self):
        # Triangle points (3D vectors with z=0)
        A = np.array([-3.0, -1.0, 0.0])
        B = np.array([ 3.0, -1.0, 0.0])
        C = np.array([ 0.0,  2.0, 0.0])

        # Draw triangle and labels
        triangle = Polygon(A, B, C, color=WHITE)
        labelA = Text("A").next_to(A, LEFT+DOWN*0.1)
        labelB = Text("B").next_to(B, RIGHT+DOWN*0.1)
        labelC = Text("C").next_to(C, UP*0.1)
        self.play(Create(triangle), Write(VGroup(labelA, labelB, labelC)))
        self.wait(0.5)

        # ---- Helper geometry functions ----
        def to3(P):
            return np.array([P[0], P[1], 0.0])

        def perp_bisector(P, Q, color=GREY):
            P3, Q3 = to3(P), to3(Q)
            mid = (P3 + Q3) / 2.0
            vec = Q3 - P3
            perp = np.array([-vec[1], vec[0], 0.0])
            perp /= np.linalg.norm(perp)
            return Line(mid - perp * 6, mid + perp * 6, color=color)

        def altitude(P, A_, B_, color=GREY):
            P3, A3, B3 = to3(P), to3(A_), to3(B_)
            AB = B3 - A3
            t = np.dot(P3[:2] - A3[:2], AB[:2]) / np.dot(AB[:2], AB[:2])
            foot = A3 + t * AB
            return Line(P3, foot, color=color)

        def angle_bisector(vertex, p1, p2, color=RED):
            v = to3(vertex); u1 = to3(p1) - v; u2 = to3(p2) - v
            u1 = u1 / np.linalg.norm(u1)
            u2 = u2 / np.linalg.norm(u2)
            bis = u1 + u2
            bis = bis / np.linalg.norm(bis)
            return Line(v, v + bis * 6, color=color)

        def intersect_two_lines(P1, P2, Q1, Q2):
            # Solve P1 + s*(P2-P1) = Q1 + t*(Q2-Q1) in 2D (x,y)
            p = P1[:2]; r = (P2 - P1)[:2]
            q = Q1[:2]; s = (Q2 - Q1)[:2]
            M = np.column_stack((r, -s))
            if abs(np.linalg.det(M)) < 1e-8:
                return None
            sol = np.linalg.solve(M, q - p)
            s_val = sol[0]
            inter = P1 + np.append(s_val * r, 0.0)
            return inter

        def dist_point_to_line(P, A_, B_):
            P3, A3, B3 = to3(P), to3(A_), to3(B_)
            num = abs(np.cross((B3 - A3)[:2], (A3 - P3)[:2]))
            den = np.linalg.norm((B3 - A3)[:2])
            return num / den

        # -------- Option A: Perpendicular bisectors (Circumcenter) --------
        titleA = Text("Option A — Médianes perpendiculaires", font_size=28).to_edge(UP)
        self.play(FadeIn(titleA))
        pb1 = perp_bisector(A, B, color=GREY)
        pb2 = perp_bisector(B, C, color=GREY)
        pb3 = perp_bisector(C, A, color=GREY)
        self.play(Create(pb1), Create(pb2), Create(pb3))
        inter_circ = intersect_two_lines(pb1.get_start(), pb1.get_end(), pb2.get_start(), pb2.get_end())
        if inter_circ is not None:
            dot_cc = Dot(inter_circ, color=YELLOW)
            circ = Circle(radius=np.linalg.norm(inter_circ - A)).move_to(inter_circ)
            self.play(FadeIn(dot_cc), Create(circ))
            self.wait(1)
            self.play(FadeOut(circ, dot_cc))
        self.play(FadeOut(pb1, pb2, pb3, titleA))
        self.wait(0.5)

        # -------- Option B: Altitudes (Orthocenter) --------
        titleB = Text("Option B — Hauteurs", font_size=28).to_edge(UP)
        self.play(FadeIn(titleB))
        alt1 = altitude(A, B, C, color=GREY)
        alt2 = altitude(B, A, C, color=GREY)
        alt3 = altitude(C, A, B, color=GREY)
        self.play(Create(alt1), Create(alt2), Create(alt3))
        inter_ortho = intersect_two_lines(alt1.get_start(), alt1.get_end(), alt2.get_start(), alt2.get_end())
        if inter_ortho is not None:
            dot_ortho = Dot(inter_ortho, color=YELLOW)
            self.play(FadeIn(dot_ortho))
            self.wait(1)
            self.play(FadeOut(dot_ortho))
        self.play(FadeOut(alt1, alt2, alt3, titleB))
        self.wait(0.5)

        # -------- Option C: Angle bisectors (Incenter) — CORRECT --------
        titleC = Text("Option C — Bissectrices (Correct)", font_size=28, color=RED).to_edge(UP)
        self.play(FadeIn(titleC))
        bis1 = angle_bisector(A, B, C, color=RED)
        bis2 = angle_bisector(B, A, C, color=RED)
        bis3 = angle_bisector(C, A, B, color=RED)
        self.play(Create(bis1), Create(bis2), Create(bis3))
        inter_in = intersect_two_lines(bis1.get_start(), bis1.get_end(), bis2.get_start(), bis2.get_end())
        if inter_in is not None:
            dot_I = Dot(inter_in, color=RED)
            self.play(FadeIn(dot_I))
            r_in = dist_point_to_line(inter_in, A, B)
            incircle = Circle(radius=r_in).move_to(inter_in)
            self.play(Create(incircle))
            self.wait(1)
        self.play(FadeOut(bis1, bis2, bis3, titleC))
        self.wait(0.5)

        # -------- Option D: (Circumcenter shown again for clarity) --------
        titleD = Text("Option D — Centre du cercle circonscrit", font_size=28).to_edge(UP)
        self.play(FadeIn(titleD))
        pb1b = perp_bisector(A, B, color=GREY)
        pb2b = perp_bisector(B, C, color=GREY)
        self.play(Create(pb1b), Create(pb2b))
        if inter_circ is not None:
            dot_cc2 = Dot(inter_circ, color=GREEN)
            circ2 = Circle(radius=np.linalg.norm(inter_circ - A)).move_to(inter_circ)
            self.play(FadeIn(dot_cc2), Create(circ2))
            self.wait(1)
            self.play(FadeOut(dot_cc2, circ2))
        self.play(FadeOut(pb1b, pb2b, titleD))
        self.wait(0.5)

        # -------- Final conclusion --------
        conclusion = Text("Réponse correcte : C. Intersection des bissectrices", font_size=30, color=YELLOW).to_edge(DOWN)
        self.play(Write(conclusion))
        self.wait(3)
